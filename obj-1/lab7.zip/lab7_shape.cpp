#include <iostream>
#include <math.h>
using namespace std;

class shape
{
	protected:
		int x;
		int y;
		char name;
	public:
		
		virtual float perimeter()= 0;
};

class twoDimen:public shape
{
	protected:
		int coordinate;
	public:
		virtual float findS() = 0;
		void showdata();
};

class circle:public twoDimen
{		
	public:
		int radius;
		float findS()
		{
			return 3.14*radius*radius;
		}
		float perimeter()
		{
			return radius*3.14*2;
		}
		void showdata(){		
			int i;
			cout<<"\n~~~~~~~~~~~~~~~~~~~~~~~CircLe~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
			circle toirog[11];
			cout<<"eremblegdeegvi: "<<endl;
			for(i = 1; i<=10; i++){
				cout <<"toirgiin radius:";
				cin >>toirog[i].radius;
				cout << "toirgiin perimeter:" << toirog[i].perimeter() << endl;
				cout <<"toirgiiin talbai:"<< toirog[i].findS()<< endl;
			}
			for(i = 1; i <=10; i++){
				circle key = toirog[i];
				int j = i-1;
				while( j >= 0 && toirog[j].findS() < key.findS() ){
				    toirog[j+1] = toirog[j];
				    j = j-1;
				}
				toirog[j+1] = key;
			}
			cout<<"\nEremblegdsen talbai: "<<endl;
			for(i = 1; i<=10; i++)
				cout<<toirog[i].findS()<<endl;
		}
};


class square:public twoDimen
{		
	public:
		int tal;
		float findS()
		{
			return tal*tal;
		}
		float perimeter()
		{
			return 4*tal;
		}
		void showdata()
		{
			int i;
			cout << "\n~~~~~~~~~~~~~~~~~~~~~Square~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
			square k[11];
			cout<<"Eremblegdeegvi: "<<endl;
			for(i = 1; i<=10; i++)
			{
				cout << "kwadrattin tal:";
				cin >> k[i].tal;
				cout << "Kwadratiin perimeter:" << k[i].perimeter() << endl;
				cout << "Kwadratiin talbai:" << k[i].findS() <<endl;
			}
			for(i = 1; i <=10; i++){
				square key = k[i];
				int j = i-1;
				while( j >= 0 && k[j].findS() < key.findS() ){
					k[j+1] = k[j];
					j = j-1;
				}
				k[j+1] = key;
		    }
			cout<<"\nEremblegdsen talbai: "<<endl;
			for(i = 1; i<=10; i++)
				cout<<k[i].findS()<<endl;
		}
};
class triangle:public twoDimen
{		
	public:
		int tal;
		float findS()
		{
			float p = (tal+tal+tal)/2; 
    		return sqrt(p*(p-tal)*(p-tal)*(p-tal));
		}
		float perimeter()
		{
			float p = tal+tal+tal; 
    		return p;
		}
		void showdata()
		{
			int i;
			cout << "\n~~~~~~~~~~~~~~~~~~~~~Triangle~~~~~~~~~~~~~~~~~~~~~~~~~\n";
			triangle t[11];
			cout<<"eremblegdeegvi: "<<endl;
			for(i = 1; i<=10; i++)
			{
				cout << "Gurwaljnii tal:";
				cin >> t[i].tal;
				cout << "Gurwaljnii perimeter:" << t[i].perimeter() << endl;
				cout << "Gurwaljnii talbai:" << t[i].findS() << endl;
			}
			for(i = 1; i <=10; i++){
				triangle key = t[i];
				int j = i-1;
				while( j >= 0 && t[j].findS() < key.findS() ){
				    t[j+1] = t[j];
				    j = j-1;
				}
				t[j+1] = key;
			}
			cout<<"\nEremblegdsen talbai: "<<endl;
			for(i = 1; i<=10; i++)
				cout<<t[i].findS()<<endl;
		}
};

int main()
{
	circle cir;
	square sq;
	triangle tr;
	cir.showdata();
	sq.showdata();
	tr.showdata();

}
