#include<iostream>
using namespace std;
void change(int *a, int *b);
int main(){
  int i,j;
  cin>>i>>j;
  cout<<i;
  cout<<j<<"\n";
  change(&i, &j);
  cout<<i<<j;
}
void change(int *a, int *b){
   int s=*a;
   *a=*b;
   *b=s;
}
