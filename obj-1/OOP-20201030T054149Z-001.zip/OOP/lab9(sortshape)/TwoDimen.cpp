//
//  TwoDimen.cpp
//  shape
//
//  Created by MacUser on 11/20/18.
//  Copyright © 2018 MacUser. All rights reserved.
//

#include "TwoDimen.hpp"
#include"shape.hpp"
#include<iostream>
using namespace std;

TwoDimen::TwoDimen(){
    
}


TwoDimen::TwoDimen(string col, int x, int y):shape(col,x,y){
    
}

